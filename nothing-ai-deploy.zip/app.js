(function () {
  const screen = document.getElementById('phoneScreen');
  if (!screen) return;

  const frames = screen.querySelectorAll('.frame');
  const tapToWake = document.getElementById('tapToWake');
  const frameMorning = document.getElementById('frame-morning');
  const frameTasks = document.getElementById('frame-tasks');

  function showFrame(id) {
    screen.classList.remove('swipe-in-progress');
    frameMorning.classList.remove('sliding-out');
    if (frameTasks) frameTasks.classList.remove('sliding-in');
    frames.forEach(function (f) {
      f.classList.toggle('active', f.dataset.frame === id);
    });
  }

  // Swipe left (right-to-left) on the page (when on Good Morning) → next frame
  var startX = 0, startY = 0;

  function onSwipeEnd(e) {
    var endX, endY;
    if (e.type === 'touchend') {
      if (!e.changedTouches || !e.changedTouches.length) return;
      endX = e.changedTouches[0].clientX;
      endY = e.changedTouches[0].clientY;
    } else {
      endX = e.clientX;
      endY = e.clientY;
    }
    var dx = endX - startX;
    var dy = endY - startY;
    if (frameMorning.classList.contains('active') && frameTasks && dx < -45 && Math.abs(dy) < 120) {
      screen.classList.add('swipe-in-progress');
      frameMorning.classList.add('sliding-out');
      frameTasks.classList.add('active');
      // Next frame: start slide-in so transition runs from translateX(100%) → 0
      requestAnimationFrame(function () {
        requestAnimationFrame(function () {
          frameTasks.classList.add('sliding-in');
        });
      });
      setTimeout(function () { showFrame('tasks'); }, 420);
    }
  }

  function onSwipeStart(e) {
    if (e.type === 'mousedown' && e.button !== 0) return;
    var t = e.type === 'touchstart' ? e.touches[0] : e;
    startX = t.clientX;
    startY = t.clientY;
    if (e.type === 'touchstart') {
      document.addEventListener('touchend', onSwipeEnd, { passive: true, once: true });
    } else {
      document.addEventListener('mouseup', onSwipeEnd, { once: true });
    }
  }

  screen.addEventListener('touchstart', onSwipeStart, { passive: true });
  screen.addEventListener('mousedown', onSwipeStart);

  // Tap to wake: lock → morning
  if (tapToWake) {
    tapToWake.addEventListener('click', function () {
      showFrame('morning');
    });
  }

  // Cards with data-goto
  screen.querySelectorAll('[data-goto]').forEach(function (el) {
    el.addEventListener('click', function () {
      var target = el.getAttribute('data-goto');
      if (target) showFrame(target);
    });
  });

  // Bottom nav (both old .bottom-nav and new f2 nav)
  screen.querySelectorAll('.bottom-nav [data-frame], .f2-navbar [data-frame]').forEach(function (btn) {
    btn.addEventListener('click', function () {
      var target = btn.getAttribute('data-frame');
      if (target) showFrame(target);
    });
  });

  // Start on lock
  showFrame('lock');
})();
